#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "beuip.h"

static int send_local(const void *buf, size_t len) {
    int sockfd;
    struct sockaddr_in dst;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket");
        return 1;
    }

    memset(&dst, 0, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(BEUIP_PORT);
    dst.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    if (sendto(sockfd, buf, len, 0, (struct sockaddr *)&dst, sizeof(dst)) < 0) {
        perror("sendto");
        close(sockfd);
        return 1;
    }

    close(sockfd);
    return 0;
}

int main(int argc, char *argv[]) {
    char buf[MAX_MSG];
    size_t len;

    if (argc < 2) {
        fprintf(stderr, "Usage:\n");
        fprintf(stderr, "  %s liste\n", argv[0]);
        fprintf(stderr, "  %s user <pseudo> <message>\n", argv[0]);
        fprintf(stderr, "  %s all <message>\n", argv[0]);
        return EXIT_FAILURE;
    }

    if (strcmp(argv[1], "liste") == 0) {
        buf[0] = '3';
        memcpy(buf + 1, BEUIP_MAGIC, BEUIP_MAGIC_LEN);
        len = 6;
        return send_local(buf, len);
    }

    if (strcmp(argv[1], "user") == 0) {
        if (argc != 4) {
            fprintf(stderr, "Usage: %s user <pseudo> <message>\n", argv[0]);
            return EXIT_FAILURE;
        }

        buf[0] = '4';
        memcpy(buf + 1, BEUIP_MAGIC, BEUIP_MAGIC_LEN);
        strcpy(buf + 6, argv[2]);
        strcpy(buf + 6 + strlen(argv[2]) + 1, argv[3]);

        len = 6 + strlen(argv[2]) + 1 + strlen(argv[3]) + 1;
        return send_local(buf, len);
    }

    if (strcmp(argv[1], "all") == 0) {
        if (argc != 3) {
            fprintf(stderr, "Usage: %s all <message>\n", argv[0]);
            return EXIT_FAILURE;
        }

        buf[0] = '5';
        memcpy(buf + 1, BEUIP_MAGIC, BEUIP_MAGIC_LEN);
        strcpy(buf + 6, argv[2]);

        len = 6 + strlen(argv[2]) + 1;
        return send_local(buf, len);
    }

    fprintf(stderr, "Commande inconnue\n");
    return EXIT_FAILURE;
}
