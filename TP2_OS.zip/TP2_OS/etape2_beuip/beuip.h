#ifndef BEUIP_H
#define BEUIP_H

#include <netinet/in.h>

#define BEUIP_PORT 9998
#define BEUIP_MAGIC "BEUIP"
#define BEUIP_MAGIC_LEN 5
#define MAX_MSG 1024
#define MAX_PEERS 255
#define MAX_PSEUDO 64
#define BROADCAST_IP "192.168.88.255"

typedef struct {
    int used;
    struct in_addr ip;
    char pseudo[MAX_PSEUDO];
} Peer;

#endif
