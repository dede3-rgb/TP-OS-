#ifndef GESCOM_H
#define GESCOM_H

#define NBMAXC 20
#define MAXMOTS 100

typedef struct {
    char *nom;
    int (*fonction)(int, char **);
} CommandInt;

extern char *Mots[MAXMOTS];
extern int NMots;

char *copyString(const char *s);
int analyseCom(char *b);
void freeMots(void);

void ajouteCom(char *nom, int (*f)(int, char **));
int execComInt(int n, char **p);
int execComExt(char **p);

int ChangeDir(int n, char **p);
int PrintDir(int n, char **p);
int Version(int n, char **p);

int execPipe(char *left_cmd, char *right_cmd);
int execRedir(char *cmd_segment);

#endif
