#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <errno.h>

#define BEUIP_PORT 9998
#define BEUIP_MAGIC "BEUIP"
#define MAX_MSG 1024
#define MAX_PEERS 255
#define MAX_PSEUDO 64
#define BROADCAST_IP "192.168.88.255"

typedef struct {
    int used;
    struct in_addr ip;
    char pseudo[MAX_PSEUDO];
} Peer;

static Peer peers[MAX_PEERS];
static volatile sig_atomic_t stop_server = 0;
static char my_pseudo[MAX_PSEUDO];
static pid_t serveur_pid = -1;

static void handle_stop(int sig) {
    (void)sig;
    stop_server = 1;
}

static int is_localhost(struct sockaddr_in *src) {
    return ntohl(src->sin_addr.s_addr) == 0x7F000001;
}

static int find_peer_by_ip(struct in_addr ip) {
    for (int i = 0; i < MAX_PEERS; i++) {
        if (peers[i].used && peers[i].ip.s_addr == ip.s_addr) {
            return i;
        }
    }
    return -1;
}

static int find_peer_by_pseudo(const char *pseudo) {
    for (int i = 0; i < MAX_PEERS; i++) {
        if (peers[i].used && strcmp(peers[i].pseudo, pseudo) == 0) {
            return i;
        }
    }
    return -1;
}

static void add_peer(struct in_addr ip, const char *pseudo) {
    if (find_peer_by_ip(ip) >= 0) return;
    if (find_peer_by_pseudo(pseudo) >= 0) return;

    for (int i = 0; i < MAX_PEERS; i++) {
        if (!peers[i].used) {
            peers[i].used = 1;
            peers[i].ip = ip;
            strncpy(peers[i].pseudo, pseudo, MAX_PSEUDO - 1);
            peers[i].pseudo[MAX_PSEUDO - 1] = '\0';
            return;
        }
    }
}

static void remove_peer(struct in_addr ip, const char *pseudo) {
    for (int i = 0; i < MAX_PEERS; i++) {
        if (peers[i].used &&
            peers[i].ip.s_addr == ip.s_addr &&
            strcmp(peers[i].pseudo, pseudo) == 0) {
            peers[i].used = 0;
            peers[i].pseudo[0] = '\0';
            return;
        }
    }
}

static void print_peers(void) {
    printf("Liste des présents :\n");
    for (int i = 0; i < MAX_PEERS; i++) {
        if (peers[i].used) {
            printf("- %s : %s\n", peers[i].pseudo, inet_ntoa(peers[i].ip));
        }
    }
}

static int valid_msg(const char *buf, ssize_t len) {
    if (len < 6) return 0;
    if (memcmp(buf + 1, BEUIP_MAGIC, 5) != 0) return 0;
    return 1;
}

static void send_packet(int sock, const struct sockaddr_in *dst,
                        char code, const void *payload, size_t payload_len) {
    char buf[MAX_MSG];

    if (6 + payload_len > sizeof(buf)) return;

    buf[0] = code;
    memcpy(buf + 1, BEUIP_MAGIC, 5);

    if (payload_len > 0) {
        memcpy(buf + 6, payload, payload_len);
    }

    sendto(sock, buf, 6 + payload_len, 0,
           (const struct sockaddr *)dst, sizeof(*dst));
}

static void send_broadcast_ident(int sock) {
    struct sockaddr_in dst;

    memset(&dst, 0, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(BEUIP_PORT);
    inet_aton(BROADCAST_IP, &dst.sin_addr);

    send_packet(sock, &dst, '1', my_pseudo, strlen(my_pseudo) + 1);
}

static void send_broadcast_leave(int sock) {
    struct sockaddr_in dst;

    memset(&dst, 0, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(BEUIP_PORT);
    inet_aton(BROADCAST_IP, &dst.sin_addr);

    send_packet(sock, &dst, '0', my_pseudo, strlen(my_pseudo) + 1);
}

/* CORRECTION IMPORTANTE :
   cette fonction doit renvoyer 1 quand la commande interne a été traitée,
   sinon biceps essaie ensuite d'exécuter "mess" comme commande externe. */
static int send_local(const void *buf, size_t len) {
    int sockfd;
    struct sockaddr_in dst;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket");
        return 1;
    }

    memset(&dst, 0, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(BEUIP_PORT);
    dst.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    if (sendto(sockfd, buf, len, 0, (struct sockaddr *)&dst, sizeof(dst)) < 0) {
        perror("sendto");
        close(sockfd);
        return 1;
    }

    close(sockfd);
    return 1;
}

static void run_server(const char *pseudo) {
    int sockfd;
    struct sockaddr_in servaddr, srcaddr;
    socklen_t srclen = sizeof(srcaddr);
    char buf[MAX_MSG];
    ssize_t n;
    int opt = 1;

    memset(peers, 0, sizeof(peers));
    stop_server = 0;

    strncpy(my_pseudo, pseudo, MAX_PSEUDO - 1);
    my_pseudo[MAX_PSEUDO - 1] = '\0';

    signal(SIGUSR1, handle_stop);

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("setsockopt SO_REUSEADDR");
    }

    if (setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &opt, sizeof(opt)) < 0) {
        perror("setsockopt SO_BROADCAST");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(BEUIP_PORT);

    if (bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("bind");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("BEUIP lancé avec pseudo %s\n", my_pseudo);
    send_broadcast_ident(sockfd);

    while (!stop_server) {
        n = recvfrom(sockfd, buf, sizeof(buf) - 1, 0,
                     (struct sockaddr *)&srcaddr, &srclen);

        if (n < 0) {
            if (errno == EINTR) continue;
            perror("recvfrom");
            break;
        }

        buf[n] = '\0';

        if (!valid_msg(buf, n)) continue;

        char code = buf[0];
        char *payload = buf + 6;

        if (code == '1') {
            add_peer(srcaddr.sin_addr, payload);
            send_packet(sockfd, &srcaddr, '2', my_pseudo, strlen(my_pseudo) + 1);
        }
        else if (code == '2') {
            add_peer(srcaddr.sin_addr, payload);
        }
        else if (code == '3') {
            if (is_localhost(&srcaddr)) {
                print_peers();
            }
        }
        else if (code == '4') {
            if (!is_localhost(&srcaddr)) continue;

            char *target = payload;
            char *message = payload + strlen(target) + 1;

            int idx = find_peer_by_pseudo(target);
            if (idx >= 0) {
                struct sockaddr_in dst;
                memset(&dst, 0, sizeof(dst));
                dst.sin_family = AF_INET;
                dst.sin_port = htons(BEUIP_PORT);
                dst.sin_addr = peers[idx].ip;
                send_packet(sockfd, &dst, '9', message, strlen(message) + 1);
            } else {
                printf("Pseudo %s introuvable\n", target);
            }
        }
        else if (code == '5') {
            if (!is_localhost(&srcaddr)) continue;

            for (int i = 0; i < MAX_PEERS; i++) {
                if (peers[i].used) {
                    struct sockaddr_in dst;
                    memset(&dst, 0, sizeof(dst));
                    dst.sin_family = AF_INET;
                    dst.sin_port = htons(BEUIP_PORT);
                    dst.sin_addr = peers[i].ip;
                    send_packet(sockfd, &dst, '9', payload, strlen(payload) + 1);
                }
            }
        }
        else if (code == '9') {
            int idx = find_peer_by_ip(srcaddr.sin_addr);
            if (idx >= 0) {
                printf("Message de %s : %s\n", peers[idx].pseudo, payload);
            } else {
                printf("Message reçu d'une IP inconnue : %s\n", payload);
            }
        }
        else if (code == '0') {
            remove_peer(srcaddr.sin_addr, payload);
            printf("%s a quitté le réseau\n", payload);
        }
    }

    send_broadcast_leave(sockfd);
    close(sockfd);
    printf("Serveur BEUIP arrêté\n");
    exit(0);
}

static int beuip_start(const char *pseudo) {
    if (serveur_pid > 0) {
        fprintf(stderr, "beuip: serveur déjà lancé\n");
        return 1;
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        run_server(pseudo);
    }

    serveur_pid = pid;
    printf("beuip: serveur lancé pid=%d\n", pid);
    return 1;
}

static int beuip_stop(void) {
    if (serveur_pid <= 0) {
        fprintf(stderr, "beuip: aucun serveur lancé\n");
        return 1;
    }

    if (kill(serveur_pid, SIGUSR1) != 0) {
        perror("kill");
        return 1;
    }

    waitpid(serveur_pid, NULL, 0);
    serveur_pid = -1;
    printf("beuip: serveur arrêté\n");
    return 1;
}

static int mess_list(void) {
    char buf[16];

    buf[0] = '3';
    memcpy(buf + 1, BEUIP_MAGIC, 5);

    return send_local(buf, 6);
}

static int mess_user(const char *pseudo, const char *message) {
    char buf[MAX_MSG];

    buf[0] = '4';
    memcpy(buf + 1, BEUIP_MAGIC, 5);
    strcpy(buf + 6, pseudo);
    strcpy(buf + 6 + strlen(pseudo) + 1, message);

    return send_local(buf, 6 + strlen(pseudo) + 1 + strlen(message) + 1);
}

static int mess_all(const char *message) {
    char buf[MAX_MSG];

    buf[0] = '5';
    memcpy(buf + 1, BEUIP_MAGIC, 5);
    strcpy(buf + 6, message);

    return send_local(buf, 6 + strlen(message) + 1);
}

int BeuipCmd(int n, char **p) {
    if (n < 2) {
        fprintf(stderr, "usage: beuip start <pseudo> | beuip stop\n");
        return 1;
    }

    if (strcmp(p[1], "start") == 0) {
        if (n != 3) {
            fprintf(stderr, "usage: beuip start <pseudo>\n");
            return 1;
        }
        return beuip_start(p[2]);
    }

    if (strcmp(p[1], "stop") == 0) {
        return beuip_stop();
    }

    fprintf(stderr, "usage: beuip start <pseudo> | beuip stop\n");
    return 1;
}

int MessCmd(int n, char **p) {
    if (n < 2) {
        fprintf(stderr, "usage: mess list | mess user <pseudo> <msg> | mess all <msg>\n");
        return 1;
    }

    if (strcmp(p[1], "list") == 0) {
        return mess_list();
    }

    if (strcmp(p[1], "user") == 0) {
        if (n < 4) {
            fprintf(stderr, "usage: mess user <pseudo> <msg>\n");
            return 1;
        }

        char msg[512] = "";
        for (int i = 3; i < n; i++) {
            strcat(msg, p[i]);
            if (i + 1 < n) strcat(msg, " ");
        }

        return mess_user(p[2], msg);
    }

    if (strcmp(p[1], "all") == 0) {
        if (n < 3) {
            fprintf(stderr, "usage: mess all <msg>\n");
            return 1;
        }

        char msg[512] = "";
        for (int i = 2; i < n; i++) {
            strcat(msg, p[i]);
            if (i + 1 < n) strcat(msg, " ");
        }

        return mess_all(msg);
    }

    fprintf(stderr, "usage: mess list | mess user <pseudo> <msg> | mess all <msg>\n");
    return 1;
}
