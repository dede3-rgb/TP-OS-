#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "gescom.h"

char *Mots[MAXMOTS];
int NMots = 0;

static CommandInt tabComInt[NBMAXC];
static int nbComActual = 0;

char *copyString(const char *s) {
    if (s == NULL) return NULL;

    char *copy = malloc(strlen(s) + 1);
    if (copy == NULL) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    strcpy(copy, s);
    return copy;
}

void freeMots(void) {
    for (int i = 0; i < NMots; i++) {
        free(Mots[i]);
        Mots[i] = NULL;
    }
    NMots = 0;
}

int analyseCom(char *b) {
    freeMots();

    char *token;
    while ((token = strsep(&b, " \t\n")) != NULL) {
        if (*token == '\0') continue;

        if (NMots >= MAXMOTS - 1) {
            fprintf(stderr, "Trop d'arguments\n");
            break;
        }

        Mots[NMots++] = copyString(token);
    }

    Mots[NMots] = NULL;
    return NMots;
}

void ajouteCom(char *nom, int (*f)(int, char **)) {
    if (nbComActual >= NBMAXC) {
        fprintf(stderr, "Trop de commandes internes\n");
        exit(EXIT_FAILURE);
    }

    tabComInt[nbComActual].nom = nom;
    tabComInt[nbComActual].fonction = f;
    nbComActual++;
}

int execComInt(int n, char **p) {
    if (n == 0 || p[0] == NULL) return 0;

    for (int i = 0; i < nbComActual; i++) {
        if (strcmp(p[0], tabComInt[i].nom) == 0) {
            return tabComInt[i].fonction(n, p);
        }
    }

    return 0;
}

int execComExt(char **p) {
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        execvp(p[0], p);
        perror("execvp");
        exit(EXIT_FAILURE);
    }

    waitpid(pid, NULL, 0);
    return 1;
}

static char *trim_spaces(char *s) {
    while (*s == ' ' || *s == '\t') s++;

    if (*s == '\0') return s;

    char *end = s + strlen(s) - 1;
    while (end > s && (*end == ' ' || *end == '\t' || *end == '\n')) {
        *end = '\0';
        end--;
    }

    return s;
}

int execPipe(char *left_cmd, char *right_cmd) {
    int pipefd[2];
    pid_t p1, p2;

    left_cmd = trim_spaces(left_cmd);
    right_cmd = trim_spaces(right_cmd);

    if (pipe(pipefd) < 0) {
        perror("pipe");
        return 1;
    }

    p1 = fork();
    if (p1 < 0) {
        perror("fork");
        return 1;
    }

    if (p1 == 0) {
        dup2(pipefd[1], STDOUT_FILENO);
        close(pipefd[0]);
        close(pipefd[1]);

        analyseCom(left_cmd);
        if (Mots[0] == NULL) exit(EXIT_FAILURE);

        execvp(Mots[0], Mots);
        perror("execvp");
        exit(EXIT_FAILURE);
    }

    p2 = fork();
    if (p2 < 0) {
        perror("fork");
        return 1;
    }

    if (p2 == 0) {
        dup2(pipefd[0], STDIN_FILENO);
        close(pipefd[1]);
        close(pipefd[0]);

        analyseCom(right_cmd);
        if (Mots[0] == NULL) exit(EXIT_FAILURE);

        execvp(Mots[0], Mots);
        perror("execvp");
        exit(EXIT_FAILURE);
    }

    close(pipefd[0]);
    close(pipefd[1]);

    waitpid(p1, NULL, 0);
    waitpid(p2, NULL, 0);

    return 1;
}

int execRedir(char *cmd_segment) {
    char *file;
    int fd;
    int append = 0;

    file = strstr(cmd_segment, ">>");
    if (file != NULL) {
        *file = '\0';
        file += 2;
        append = 1;
    } else {
        file = strchr(cmd_segment, '>');
        if (file == NULL) return 0;
        *file = '\0';
        file++;
    }

    cmd_segment = trim_spaces(cmd_segment);
    file = trim_spaces(file);

    if (*file == '\0') {
        fprintf(stderr, "biceps: fichier de redirection manquant\n");
        return 1;
    }

    fd = open(file, O_WRONLY | O_CREAT | (append ? O_APPEND : O_TRUNC), 0644);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        close(fd);
        return 1;
    }

    if (pid == 0) {
        dup2(fd, STDOUT_FILENO);
        close(fd);

        analyseCom(cmd_segment);
        if (Mots[0] == NULL) exit(EXIT_FAILURE);

        execvp(Mots[0], Mots);
        perror("execvp");
        exit(EXIT_FAILURE);
    }

    close(fd);
    waitpid(pid, NULL, 0);

    return 1;
}

int ChangeDir(int n, char **p) {
    const char *dest;

    if (n < 2) {
        dest = getenv("HOME");
        if (dest == NULL) {
            fprintf(stderr, "cd: HOME non défini\n");
            return 1;
        }
    } else {
        dest = p[1];
    }

    if (chdir(dest) != 0) {
        perror("cd");
    }

    return 1;
}

int PrintDir(int n, char **p) {
    (void)n;
    (void)p;

    char cwd[1024];
    if (getcwd(cwd, sizeof(cwd)) == NULL) {
        perror("getcwd");
        return 1;
    }

    printf("%s\n", cwd);
    return 1;
}

int Version(int n, char **p) {
    (void)n;
    (void)p;
    printf("biceps version 2.0\n");
    return 1;
}
