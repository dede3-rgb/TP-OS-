#ifndef CREME_H
#define CREME_H

int BeuipCmd(int n, char **p);
int MessCmd(int n, char **p);

#endif
