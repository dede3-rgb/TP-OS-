#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include "gescom.h"
#include "creme.h"

int Sortie(int n, char **p) {
    (void)n;
    (void)p;
    freeMots();
    printf("Exiting biceps... Goodbye!\n");
    exit(0);
}

void handle_sigint(int sig) {
    (void)sig;
    write(STDOUT_FILENO, "\n", 1);
}

void majComInt(void) {
    ajouteCom("exit", Sortie);
    ajouteCom("cd", ChangeDir);
    ajouteCom("pwd", PrintDir);
    ajouteCom("vers", Version);
    ajouteCom("beuip", BeuipCmd);
    ajouteCom("mess", MessCmd);
}

char *build_prompt(void) {
    char hostname[256];
    char *user = getenv("USER");
    char symbol = (geteuid() == 0) ? '#' : '$';

    if (gethostname(hostname, sizeof(hostname)) != 0) {
        strcpy(hostname, "machine");
    }

    if (user == NULL) user = "user";

    int size = strlen(user) + strlen(hostname) + 4;
    char *prompt = malloc(size);
    if (prompt == NULL) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    snprintf(prompt, size, "%s@%s%c ", user, hostname, symbol);
    return prompt;
}

static char *trim_spaces_local(char *s) {
    while (*s == ' ' || *s == '\t') s++;

    if (*s == '\0') return s;

    char *end = s + strlen(s) - 1;
    while (end > s && (*end == ' ' || *end == '\t' || *end == '\n')) {
        *end = '\0';
        end--;
    }

    return s;
}

int main(void) {
    char buffer[1024];
    char *line;
    char *prompt_str;

    signal(SIGINT, handle_sigint);
    majComInt();

    while (1) {
        prompt_str = build_prompt();
        printf("%s", prompt_str);
        fflush(stdout);

        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            free(prompt_str);
            Sortie(0, NULL);
        }

        free(prompt_str);

        buffer[strcspn(buffer, "\n")] = '\0';

        line = strdup(buffer);
        if (line == NULL) {
            perror("strdup");
            exit(EXIT_FAILURE);
        }

        if (*line) {
            char *line_ptr = line;
            char *seg;

            while ((seg = strsep(&line_ptr, ";")) != NULL) {
                seg = trim_spaces_local(seg);
                if (*seg == '\0') continue;

                char *p_pos = strchr(seg, '|');
                if (p_pos != NULL) {
                    *p_pos = '\0';
                    execPipe(seg, p_pos + 1);
                } else if (!execRedir(seg)) {
                    int count = analyseCom(seg);
                    if (count > 0 && !execComInt(count, Mots)) {
                        execComExt(Mots);
                    }
                }
            }
        }

        free(line);
    }

    return 0;
}
