#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define PORT 9999
#define BUFSIZE 1024

int main(int argc, char *argv[]) {
    int sockfd;
    struct sockaddr_in servaddr;
    socklen_t len = sizeof(servaddr);
    char buffer[BUFSIZE];
    char ack[BUFSIZE];
    ssize_t n;

    if (argc != 3) {
        fprintf(stderr, "Usage: %s <ip_serveur> <message>\n", argv[0]);
        return EXIT_FAILURE;
    }

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);

    if (inet_aton(argv[1], &servaddr.sin_addr) == 0) {
        fprintf(stderr, "Adresse IP invalide\n");
        close(sockfd);
        return EXIT_FAILURE;
    }

    strncpy(buffer, argv[2], BUFSIZE - 1);
    buffer[BUFSIZE - 1] = '\0';

    if (sendto(sockfd, buffer, strlen(buffer) + 1, 0,
               (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("sendto");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    n = recvfrom(sockfd, ack, BUFSIZE - 1, 0,
                 (struct sockaddr *)&servaddr, &len);
    if (n < 0) {
        perror("recvfrom");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    ack[n] = '\0';
    printf("Accusé de réception du serveur : %s\n", ack);

    close(sockfd);
    return 0;
}
